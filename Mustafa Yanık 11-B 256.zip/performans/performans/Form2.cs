﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace performans
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        Random rnd = new Random();
        private void button1_Click(object sender, EventArgs e)
        {
            int sayi = -1;
            int toplam = 0, sayac = 0;
            while (sayi != 0)
            {
                sayi = rnd.Next(0, 20);
                listBox1.Items.Add(sayi);
                toplam += sayi;
                sayac++;
            }
            textBox1.Text = listBox1.Items.Count + "";
            textBox2.Text = (toplam / sayac) + "";
        }

       
    }
}
