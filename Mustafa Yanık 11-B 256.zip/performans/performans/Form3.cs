﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace performans
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        Random rnd = new Random();
        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            int enKucuk = 101, enBuyuk = -1;
            for (int i = 0; i < 20; i++)
            {
                int sayi = rnd.Next(0, 100);
                if (sayi % 7 == 0)
                {
                    i -= 1;
                    continue;
                }
                enKucuk = sayi < enKucuk ? sayi : enKucuk;
                enBuyuk = sayi > enBuyuk ? sayi : enBuyuk;
                listBox1.Items.Add(sayi);
            }
        }
    }
}